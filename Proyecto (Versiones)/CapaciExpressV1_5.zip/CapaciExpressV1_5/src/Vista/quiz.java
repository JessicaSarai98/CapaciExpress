package Vista;

public class quiz extends javax.swing.JFrame {

    public quiz() {
        initComponents();
        
        buttonGroup1.add(p1opcA);
        buttonGroup1.add(p1opcB);
        buttonGroup1.add(p1opcC);
        
        buttonGroup2.add(p2opcA);
        buttonGroup2.add(p2opcB);
        buttonGroup2.add(p2opcC);
        
        buttonGroup3.add(p3opcA);
        buttonGroup3.add(p3opcB);
        buttonGroup3.add(p3opcC);
        
        buttonGroup4.add(p4opcA);
        buttonGroup4.add(p4opcB);
        buttonGroup4.add(p4opcB);
        
        buttonGroup5.add(p5opcA);
        buttonGroup5.add(p5opcB);
        buttonGroup5.add(p5opcC);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        buttonGroup2 = new javax.swing.ButtonGroup();
        buttonGroup3 = new javax.swing.ButtonGroup();
        buttonGroup4 = new javax.swing.ButtonGroup();
        buttonGroup5 = new javax.swing.ButtonGroup();
        jScrollPane1 = new javax.swing.JScrollPane();
        txtQuiz = new javax.swing.JTextArea();
        jLabel1 = new javax.swing.JLabel();
        p1opcC = new javax.swing.JRadioButton();
        p1opcB = new javax.swing.JRadioButton();
        p1opcA = new javax.swing.JRadioButton();
        btnSiguiente = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        p2opcA = new javax.swing.JRadioButton();
        p2opcB = new javax.swing.JRadioButton();
        p2opcC = new javax.swing.JRadioButton();
        jLabel3 = new javax.swing.JLabel();
        p3opcA = new javax.swing.JRadioButton();
        p3opcB = new javax.swing.JRadioButton();
        p3opcC = new javax.swing.JRadioButton();
        jLabel4 = new javax.swing.JLabel();
        p4opcA = new javax.swing.JRadioButton();
        p4opcB = new javax.swing.JRadioButton();
        p4opcC = new javax.swing.JRadioButton();
        jLabel5 = new javax.swing.JLabel();
        p5opcB = new javax.swing.JRadioButton();
        p5opcA = new javax.swing.JRadioButton();
        p5opcC = new javax.swing.JRadioButton();
        btnIniciar = new javax.swing.JButton();
        btnRegresar = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        txtQuiz.setColumns(20);
        txtQuiz.setRows(5);
        txtQuiz.setEnabled(false);
        jScrollPane1.setViewportView(txtQuiz);

        jLabel1.setText("Pregunta 1:");

        p1opcC.setText("C");

        p1opcB.setText("B");
        p1opcB.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                p1opcBActionPerformed(evt);
            }
        });

        p1opcA.setText("A");
        p1opcA.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                p1opcAActionPerformed(evt);
            }
        });

        btnSiguiente.setText("Siguientes preguntas....");

        jLabel2.setText("Pregunta 2:");

        p2opcA.setText("A");
        p2opcA.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                p2opcAActionPerformed(evt);
            }
        });

        p2opcB.setText("B");
        p2opcB.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                p2opcBActionPerformed(evt);
            }
        });

        p2opcC.setText("C");

        jLabel3.setText("Pregunta 3:");

        p3opcA.setText("A");
        p3opcA.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                p3opcAActionPerformed(evt);
            }
        });

        p3opcB.setText("B");
        p3opcB.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                p3opcBActionPerformed(evt);
            }
        });

        p3opcC.setText("C");

        jLabel4.setText("Pregunta 4:");

        p4opcA.setText("A");
        p4opcA.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                p4opcAActionPerformed(evt);
            }
        });

        p4opcB.setText("B");
        p4opcB.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                p4opcBActionPerformed(evt);
            }
        });

        p4opcC.setText("C");

        jLabel5.setText("Pregunta 5:");

        p5opcB.setText("B");
        p5opcB.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                p5opcBActionPerformed(evt);
            }
        });

        p5opcA.setText("A");
        p5opcA.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                p5opcAActionPerformed(evt);
            }
        });

        p5opcC.setText("C");

        btnIniciar.setText("Iniciar");

        btnRegresar.setText("Regresar a inicio");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 626, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(40, 40, 40)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel3)
                                    .addComponent(p3opcA)
                                    .addComponent(p3opcC)
                                    .addComponent(p3opcB)
                                    .addGroup(layout.createSequentialGroup()
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(jLabel1)
                                            .addComponent(p1opcA)
                                            .addComponent(p1opcC)
                                            .addComponent(p1opcB)
                                            .addComponent(jLabel2)
                                            .addComponent(p2opcA)
                                            .addComponent(p2opcC)
                                            .addComponent(p2opcB))
                                        .addGap(70, 70, 70)
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(p5opcA)
                                            .addComponent(p5opcC)
                                            .addComponent(p5opcB)
                                            .addComponent(jLabel5)
                                            .addComponent(p4opcA)
                                            .addComponent(p4opcC)
                                            .addComponent(p4opcB)
                                            .addComponent(jLabel4)))))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(81, 81, 81)
                                .addComponent(btnSiguiente)))
                        .addContainerGap(71, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addComponent(btnRegresar)
                                .addGap(88, 88, 88))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addComponent(btnIniciar)
                                .addGap(116, 116, 116))))))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 489, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel1)
                            .addComponent(jLabel4))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(p1opcA, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(p1opcB, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(p1opcC, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(p4opcA, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(p4opcB, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(p4opcC, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel2)
                            .addComponent(jLabel5))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(p2opcA, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(p2opcB, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(p2opcC, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(p5opcA, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(p5opcB, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(p5opcC, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(18, 18, 18)
                        .addComponent(jLabel3)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(p3opcA, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(p3opcB, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(p3opcC, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(50, 50, 50)
                        .addComponent(btnIniciar)
                        .addGap(18, 18, 18)
                        .addComponent(btnRegresar)
                        .addGap(19, 19, 19)
                        .addComponent(btnSiguiente)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void p1opcBActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_p1opcBActionPerformed
       
    }//GEN-LAST:event_p1opcBActionPerformed

    private void p1opcAActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_p1opcAActionPerformed
       
    }//GEN-LAST:event_p1opcAActionPerformed

    private void p2opcAActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_p2opcAActionPerformed
        
    }//GEN-LAST:event_p2opcAActionPerformed

    private void p2opcBActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_p2opcBActionPerformed
        
    }//GEN-LAST:event_p2opcBActionPerformed

    private void p3opcAActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_p3opcAActionPerformed
        
    }//GEN-LAST:event_p3opcAActionPerformed

    private void p3opcBActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_p3opcBActionPerformed
        
    }//GEN-LAST:event_p3opcBActionPerformed

    private void p4opcAActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_p4opcAActionPerformed
        
    }//GEN-LAST:event_p4opcAActionPerformed

    private void p4opcBActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_p4opcBActionPerformed
        
    }//GEN-LAST:event_p4opcBActionPerformed

    private void p5opcBActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_p5opcBActionPerformed
        
    }//GEN-LAST:event_p5opcBActionPerformed

    private void p5opcAActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_p5opcAActionPerformed
        
    }//GEN-LAST:event_p5opcAActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(quiz.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(quiz.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(quiz.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(quiz.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new quiz().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    public javax.swing.JButton btnIniciar;
    public javax.swing.JButton btnRegresar;
    public javax.swing.JButton btnSiguiente;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.ButtonGroup buttonGroup2;
    private javax.swing.ButtonGroup buttonGroup3;
    private javax.swing.ButtonGroup buttonGroup4;
    private javax.swing.ButtonGroup buttonGroup5;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JScrollPane jScrollPane1;
    public javax.swing.JRadioButton p1opcA;
    public javax.swing.JRadioButton p1opcB;
    public javax.swing.JRadioButton p1opcC;
    public javax.swing.JRadioButton p2opcA;
    public javax.swing.JRadioButton p2opcB;
    public javax.swing.JRadioButton p2opcC;
    public javax.swing.JRadioButton p3opcA;
    public javax.swing.JRadioButton p3opcB;
    public javax.swing.JRadioButton p3opcC;
    public javax.swing.JRadioButton p4opcA;
    public javax.swing.JRadioButton p4opcB;
    public javax.swing.JRadioButton p4opcC;
    public javax.swing.JRadioButton p5opcA;
    public javax.swing.JRadioButton p5opcB;
    public javax.swing.JRadioButton p5opcC;
    public javax.swing.JTextArea txtQuiz;
    // End of variables declaration//GEN-END:variables
}
