package Controlador;

public class CtrlQuiz {
    
}
